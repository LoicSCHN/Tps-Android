package com.example.ventevehiculev1;

public class AnnonceLocation {
    public int id_Date;
    public AnnonceLocation(int id_Date){
        super();
        this.id_Date = id_Date;
    }
}
