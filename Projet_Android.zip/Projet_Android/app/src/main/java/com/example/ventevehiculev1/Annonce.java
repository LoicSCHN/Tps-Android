package com.example.ventevehiculev1;

public class Annonce {
    private int id;
    private int id_User;
    private int id_Voiture;
    private int prix;
    private int id_Localisation;

}
