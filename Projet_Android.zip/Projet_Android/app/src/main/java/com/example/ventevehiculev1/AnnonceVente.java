package com.example.ventevehiculev1;

public class AnnonceVente {
    public AnnonceVente() {
        super();
    }
}
