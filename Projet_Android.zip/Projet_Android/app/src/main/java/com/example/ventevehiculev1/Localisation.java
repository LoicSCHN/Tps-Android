package com.example.ventevehiculev1;

public class Localisation {
    public int id;
    public String region;
    public String departement;
    public String ville;
    public double codePostal;
}
