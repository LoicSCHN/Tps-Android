package com.example.ventevehiculev1;

public class Date {
    public int id;
    public String jourDebut;
    public String jourFin;

    public Date(int id,String jourDebut, String jourFin) {
        this.id = id;
        this.jourDebut = jourDebut;
        this.jourFin = jourFin;
    }
}
