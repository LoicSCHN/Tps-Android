package com.example.ventevehiculev1;

public class VerifException extends Exception{

    public VerifException() {
        super();
    }

    public VerifException(String s) {
        super(s);
    }
}
